#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
from tf import transformations
import math
from std_srvs.srv import SetBool, SetBoolResponse


# Robot state variables
position_ = Point()
yaw_ = 0

# Machine state
state_ = 0

# Goal
desired_position_ = Point()
desired_position_.x = 3.0
desired_position_.y = 4.0
desired_position_.z = 0.0

# Parameters
yaw_precision_ = math.pi / 5  # +/- 2 degrees allowed
dist_precision_ = 0.7

# Publisher
pub = None


def callback_odom(msg):
    global position_
    global yaw_

    # Position
    position_ = msg.pose.pose.position

    # Yaw
    quaternion = (
        msg.pose.pose.orientation.x,
        msg.pose.pose.orientation.y,
        msg.pose.pose.orientation.z,
        msg.pose.pose.orientation.w,
    )
    euler = transformations.euler_from_quaternion(quaternion)

    yaw_ = euler[2]

    # Print the quaternion for debugging
    print("Quaternion:", quaternion)

    # Debug by printing Euler angles
    print(f"Roll: {euler[0]}, Pitch: {euler[1]}, Yaw: {euler[2]}")


def change_state(state):
    global state_
    state_ = state
    print('State changed to [%s]' % state_)


def fix_yaw(des_pos):
    global yaw_, pub, yaw_precision_, state_

    # Calculate the desired yaw relative to the current yaw
    desired_yaw = math.atan2(des_pos.y - position_.y, des_pos.x - position_.x)
    err_yaw = desired_yaw - yaw_

    # Ensure err_yaw is between -pi and pi
    if err_yaw > math.pi:
        err_yaw -= 2 * math.pi
    elif err_yaw < -math.pi:
        err_yaw += 2 * math.pi

    twist_msg = Twist()
    if math.fabs(err_yaw) > yaw_precision_:
        twist_msg.angular.z = 0.3 if err_yaw > 0 else -0.3  # Updated for both directions

        pub.publish(twist_msg)

        # Debugging output
        print('Desired Yaw: %f, Current Yaw: %f, Error Yaw: %f' % (desired_yaw, yaw_, err_yaw))
    else:
        print('Yaw error: [%s]' % err_yaw)
        change_state(1)


def go_straight_ahead(des_pos):
    global yaw_, pub, yaw_precision_, state_

    desired_yaw = math.atan2(des_pos.y - position_.y, des_pos.x - position_.x)
    err_yaw = desired_yaw - yaw_
    
    # Ensure err_yaw is between -pi and pi
    if err_yaw > math.pi:
        err_yaw -= 2 * math.pi
    elif err_yaw < -math.pi:
        err_yaw += 2 * math.pi
    
    err_pos = math.sqrt(pow(des_pos.y - position_.y, 2) + pow(des_pos.x - position_.x, 2))

    if err_pos > dist_precision_:
        twist_msg = Twist()
        twist_msg.linear.x = 0.3
        pub.publish(twist_msg)
    else:
        print('Position error: [%s]' % err_pos)
        change_state(2)

        # Debugging output
        print('Desired Yaw: %f, Current Yaw: %f, Error Yaw: %f' % (desired_yaw, yaw_, err_yaw))
        print('Position error: [%s]' % err_pos)

    # Change state conditions
    if math.fabs(err_yaw) > yaw_precision_:
        print('Yaw error: [%s]' % err_yaw)
        change_state(0)


def done():
    twist_msg = Twist()
    twist_msg.linear.x = 0
    twist_msg.angular.z = 0
    pub.publish(twist_msg)


def destination_switch_callback(req):
    rospy.loginfo("Received request to switch destination. Request data: %s", req.data)
    return SetBoolResponse(success=True, message="Destination Switched successfully ")    


def main():
    global pub

    rospy.init_node('destination')
    
    srv_destination_switch = rospy.Service('/destination/destination_switch', SetBool, destination_switch_callback)
    
    pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

    sub_odom = rospy.Subscriber("/odom", Odometry, callback_odom)

    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        if state_ == 0:
            fix_yaw(desired_position_)
        elif state_ == 1:
            go_straight_ahead(desired_position_)
        elif state_ == 2:
            done()
            pass
        else:
            rospy.logerr("Unknown state")
            pass
        rospy.sleep(1.0 / 20.0)


if __name__ == '__main__':
    main()
