#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

pub = None

def callback_laser(msg):
    # Threshold distance for obstacle detection
    threshold_distance = 1.5

    # Set default velocities
    linear_x = 0.6
    angular_z = 0

    # Check obstacle proximity
    if msg.ranges[360] < threshold_distance:  # Front
        linear_x = 0
        angular_z = 1.5 if msg.ranges[0] < msg.ranges[719] else -1.5
    elif msg.ranges[0] < threshold_distance:  # Fright
        linear_x = 0
        angular_z = 1.5
    elif msg.ranges[719] < threshold_distance:  # Fleft
        linear_x = 0
        angular_z = -1.5

    # Publish the velocities
    publish_velocities(linear_x, angular_z)

def publish_velocities(linear_x, angular_z):
    msg = Twist()
    msg.linear.x = linear_x
    msg.angular.z = angular_z
    pub.publish(msg)

def main():
    global pub

    rospy.init_node("reading_laser")

    pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
    sub = rospy.Subscriber("/scan", LaserScan, callback_laser)

    rospy.spin()

if __name__ == '__main__':
    main()
